
    function timConGiap() {
      const year = document.getElementById("year").value;
      
      const tenGiap = [  
      "Tý",
      "Sửu",
      "Dần",
      "Mão",
      "Thìn",
      "Tỵ",
      "Ngọ",
      "Mùi",
      "Thân",
      "Dậu",
      "Tuất",
      "Hợi",];
      const namConGiap = (year - 4) % 12;
      
     const x=[("Con giáp của bạn là " + tenGiap[namConGiap])];
    
     document.getElementById("ketqua").innerHTML= x;

}

const hinhcongiap = document.getElementById("hinhcongiap");
hinhcongiap.src = "images/" + tenGiap + ".jpg"